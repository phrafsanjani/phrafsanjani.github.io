import java.io.*;

public class Main
{
    public static void main(String[] args)
    {
        try
        {
            // using an array of students is okay as well...
            Student student1 = new Student("Ryan", "Smith", 19, 1402, 3.7);
            Student student2 = new Student("Melika", "Roshan", 19, 1402, 3.7);
            Student student3 = new Student("Jafar", "Akbari", 19, 1402, 3);

            File file = new File("student.txt");
            FileWriter writer = new FileWriter(file);
            BufferedWriter bufferedWriter = new BufferedWriter(writer);

            bufferedWriter.write(student1.getFirstName() + ',' + student1.getFamilyName() + ',' + student1.getAge() + ',' + student1.getEntryYear() + ',' + student1.getGpa() + '\n');

            bufferedWriter.write(student2.getFirstName() + ',' + student2.getFamilyName() + ',' + student2.getAge() + ',' + student2.getEntryYear() + ',' + student2.getGpa() + '\n');

            bufferedWriter.write(student3.getFirstName() + ',' + student3.getFamilyName() + ',' + student3.getAge() + ',' + student3.getEntryYear() + ',' + student3.getGpa());

            bufferedWriter.close();
        }
        catch (IOException ex)
        {
            ex.printStackTrace();
        }
    }
}
