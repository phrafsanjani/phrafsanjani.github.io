public class Student
{
    private  String firstName;
    private  String familyName;
    private  int age;
    private  int entryYear; // four-digit number
    private  double gpa;    //on scale of 4

    public Student(String firstName, String familyName, int age, int entryYear, double gpa)
    {

        this.firstName = firstName;
        this.familyName = familyName;
        this.age = age;
        this.entryYear = entryYear;
        this.gpa = gpa;
        System.out.println(getAge() + " year old student " + getFirstName() + " " + getFamilyName() + " who entered university in "+ getEntryYear() + " and has a current GPA of " + getGpa() + " has just been created!");
    }
    
    public String getFirstName()
    {
        return firstName;
    }
    
    public String getFamilyName()
    {
        return familyName;
    }
    
    public  int getAge()
    {
        return this.age;
    }
    
    public int getEntryYear()
    {
        return entryYear;
    }

    public double getGpa()
    {
        return this.gpa;
    }
}
