import java.io.FileWriter;
import java.io.IOException;

public class Main
{
    public static void main(String[] args)
    {
        try
        {
            Student student = new Student("Ryan", "Smith", 19, 1402, 3.7);
            
            FileWriter writer = new FileWriter("student.txt");
            
            writer.write(student.getFirstName() + ',' + student.getFamilyName() + ',' + student.getAge() + ',' + student.getEntryYear() + ',' + student.getGpa());
            
            // writer.close();
        }
        catch (IOException ex)
        {
            ex.printStackTrace();
        }
    }
}
