import java.io.*;

public class Main
{
    public static void main(String[] args)
    {
        try
        {
            Student student = new Student("Ryan", "Smith", 19, 1402, 3.7);
            File file = new File("student.txt");
            FileWriter writer = new FileWriter(file);
            BufferedWriter bufferedWriter = new BufferedWriter(writer);
            bufferedWriter.write(student.getFirstName() + ',' + student.getFamilyName() + ',' + student.getAge() + ',' + student.getEntryYear() + ',' + student.getGpa());
            
            bufferedWriter.close();
        }
        catch (IOException ex)
        {
            ex.printStackTrace();
        }
    }
}
