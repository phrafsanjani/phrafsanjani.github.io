import java.io.*;

public class Main
{
    public static void main(String[] args)
    {
        try
        {
            Student student1 = new Student("Ryan", "Smith", 19, 1402, 3.7);
            Student student2 = new Student("Melika", "Roshan", 19, 1402, 3.7);
            Student student3 = new Student("Jafar", "Akbari", 19, 1402, 3);

            FileOutputStream fileStream = new FileOutputStream("students.ser");
            ObjectOutputStream os = new ObjectOutputStream(fileStream);

            os.writeObject(student1);
            os.writeObject(student2);
            os.writeObject(student3);

            os.close();
        }
        catch (IOException ex)
        {
            ex.printStackTrace();
        }
    }
}
