public class Student
{
    private  String firstName;
    private  String familyName;
    private  int age;
    private int entryYear;
    private  double gpa;

    public Student(String firstName, String familyName, int age, int entryYear, double gpa)
    {

        this.firstName = firstName;
        this.familyName = familyName;
        this.age = age;
        this.entryYear = entryYear;
        this.gpa = gpa;

    }

    public  String getFirstName()
    {
        return firstName;
    }

    public String getFamilyName()
    {
        return familyName;
    }
    public int getAge()
    {
        return age;
    }
    public int getEntryYear()
    {
        return entryYear;
    }

    public double getGpa()
    {
        return gpa;
    }




}
