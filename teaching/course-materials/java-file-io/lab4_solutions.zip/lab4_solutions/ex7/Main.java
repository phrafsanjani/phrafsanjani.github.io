import java.io.*;

public class Main
{
    public static void main(String[] args)
    {
        try
        {
            FileReader fileReader = new FileReader("student.txt");
            BufferedReader reader = new BufferedReader(fileReader);
            String line;
            int counter = 0;
            
            while ((line = reader.readLine()) != null)
            {
                String[] studentInformation = line.split(",");
                
                System.out.println("STUDENT #" + counter++);
                System.out.println("First Name: " + studentInformation[0]);
                System.out.println("Last Name:  " + studentInformation[1]);
                System.out.println("Age:        " + Integer.parseInt(studentInformation[2]));
                System.out.println("Entry Year: " + Integer.parseInt(studentInformation[3]));
                System.out.println("GPA:        " + Double.parseDouble(studentInformation[4]) + '\n');
            }
            
            reader.close();
        } catch (IOException ex)
        {
            ex.printStackTrace();
        }
    }
}
