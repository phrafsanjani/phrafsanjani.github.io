import java.io.*;

public class Main
{
    public static void main(String[] args)
    {
        try
        {
            FileInputStream fileStream = new FileInputStream("students.ser");
			ObjectInputStream os = new ObjectInputStream(fileStream);

            Student student1 = (Student)os.readObject();
            Student student2 = (Student)os.readObject();
            Student student3 = (Student)os.readObject();

            student1.printInformation();
            student2.printInformation();
            student3.printInformation();

            os.close();
        }
        catch (Exception ex)
        {
            ex.printStackTrace();
        }
    }
}
