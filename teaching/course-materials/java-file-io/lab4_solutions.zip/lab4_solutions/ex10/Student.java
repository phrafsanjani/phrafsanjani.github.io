import java.io.Serializable;

public class Student implements Serializable
{
    private  String firstName;
    private  String familyName;
    private  int age;
    private  int entryYear; // four-digit number
    private  double gpa;    //on scale of 4

    public Student(String firstName, String familyName, int age, int entryYear, double gpa)
    {

        this.firstName = firstName;
        this.familyName = familyName;
        this.age = age;
        this.entryYear = entryYear;
        this.gpa = gpa;
    }
    
    public void printInformation()
    {
        System.out.println("First Name:  " + getFirstName());
        System.out.println("Family Name: " + getFamilyName());
        System.out.println("Age:         " + getAge());
        System.out.println("Entry Year:  " + getEntryYear());
        System.out.println("GPA:         " + getGpa() + '\n');
    }
    
    public String getFirstName()
    {
        return firstName;
    }
    
    public String getFamilyName()
    {
        return familyName;
    }
    
    public  int getAge()
    {
        return this.age;
    }
    
    public int getEntryYear()
    {
        return entryYear;
    }

    public double getGpa()
    {
        return this.gpa;
    }
}
