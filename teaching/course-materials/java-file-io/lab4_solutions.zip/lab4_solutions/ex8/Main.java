import java.io.*;

public class Main
{
    public static void main(String[] args)
    {
        try
        {
            FileReader fileReader = new FileReader("student.txt");
            BufferedReader reader = new BufferedReader(fileReader);

            FileWriter writer = new FileWriter("student.csv");
            BufferedWriter bufferedWriter = new BufferedWriter(writer);

            bufferedWriter.write("First Name,Family Name,Age,Entry Year,GPA\n");

            String line;
            while ((line = reader.readLine()) != null)
            {
                String[] studentInformation = line.split(",");
                bufferedWriter.write(studentInformation[0] + "," + studentInformation[1] + "," + Integer.parseInt(studentInformation[2]) + "," + Integer.parseInt(studentInformation[3]) + "," + Double.parseDouble(studentInformation[4]) + '\n');
            }
            
            reader.close();
            bufferedWriter.close();
        }
        catch (IOException ex)
        {
            ex.printStackTrace();
        }
    }
}
