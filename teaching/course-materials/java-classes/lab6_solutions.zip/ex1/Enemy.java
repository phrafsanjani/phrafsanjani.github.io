import java.util.ArrayList;

public class Enemy
{
    private int health;
    private ArrayList<Weapon> weapons;

    public int getHealth() { return health; }
    public ArrayList<Weapon> getWeapons() { return weapons; }
    public void setHealth(int value)
    {
        health = value;
    }
    public void setWeapons(ArrayList<Weapon> weapons)
    {
        this.weapons = weapons;
    }
}