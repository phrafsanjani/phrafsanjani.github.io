public class Game
{
    public static void main(String[] args)
    {
        User[] users = new User[3];

        users[0] = new User("Ryan", new MainCharacter(), 10, 1, 2024);
        users[1] = new User("Melika", new MainCharacter(), 19, 4, 2022);
        users[2] = new User("Parsa", new MainCharacter(), 12, 3, 2023);

        for (User user : users)
            user.printInformation();
    }    
}
