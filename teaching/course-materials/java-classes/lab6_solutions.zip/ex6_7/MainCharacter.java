import java.util.ArrayList;

public class MainCharacter
{
    private int health;
    private ArrayList<Weapon> weapons;
    
    public MainCharacter() {}
}
