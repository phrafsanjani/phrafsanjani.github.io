import java.time.LocalDate;
import java.util.ArrayList;

public class User
{
    private String name;
    private MainCharacter mainCharacter;
    private LocalDate accountCreationDate;
    private LocalDate lastLogin;
    private double fund;
    private ArrayList<Item> items;

    public static void main(String[] args)
    {
        User user = new User("Mahsa", new MainCharacter(), 16, 9, 2022);
        user.setLoginMonth(11);
        user.setFund(500);
        user.printInformation();
        Item item = new Item(700);
        user.buyItem(item);
        user.printInformation();
    }

    public User(String name, MainCharacter mainCharacter, int accountCreationDay, int accountCreationMonth, int accountCreationYear)
    {
        this.name = name;
        this.mainCharacter = mainCharacter;
        this.items = new ArrayList<Item>();
        this.fund = 0;
        accountCreationDate = LocalDate.of(accountCreationYear, accountCreationMonth, accountCreationDay);
        lastLogin = accountCreationDate;
        System.out.println("Account created!");
        System.out.println("Last login at " + lastLogin);
    }

    public void setLoginMonth(int month)
    {
        lastLogin = LocalDate.of(lastLogin.getYear(), month, lastLogin.getDayOfMonth());
    }

    public void increaseFund(double value)
    {
        fund += value;
    }

    private void reduceFund(double value) throws Exception
    {
        if (value > fund)
            throw new Exception("Not enough money available in user's account!");
        else
            fund -= value;
    }

    public void buyItem(Item item)
    {
        try
        {
            reduceFund(item.getPrice());
            items.add(item);
        }
        catch (Exception ex)
        {
            ex.printStackTrace();
        }
    }

    public void setFund(int value) { fund = value; }

    public void printInformation()
    {
        System.out.println("Name: " + name);
        System.out.println("Account created at " + accountCreationDate);
        System.out.println("Last login at " + lastLogin);
        System.out.println("Fund: " + fund);
    }
}