import java.util.Scanner;

public class GuessMyNumber
{
    public static void main(String[] args)
    {
        int number = (int)(Math.random() * 500);
        int guess;
        int numberOfGuesses = 0;
        
        while (numberOfGuesses < 10)
        {
            Scanner scanner = new Scanner(System.in);
            System.out.print("Enter your guess: ");
            guess = scanner.nextInt();
            numberOfGuesses += 1;

            if (guess == number)
            {
                System.out.println("You win!");
                break;
            }
            else if (guess < number)
                System.out.println("Your guess is low!");
            else
                System.out.println("Your guess is high!");
        }
        if (numberOfGuesses >= 10) System.out.println("You lose!");
    }
}
